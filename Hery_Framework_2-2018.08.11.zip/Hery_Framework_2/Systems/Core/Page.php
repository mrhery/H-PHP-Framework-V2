<?php

class Page{
	public $title = "";
	private $meta_top = array();
	private $css_library = array(), $custom_css = array();
	private $top_script_library = array(), $top_custom_script = array();
	private $bottom_script_library = array(), $custom_script = array();
	private $js_obfuscate = false, $htmlhex = false;
	private $page = "";
	
	public function __construct($setting = array()){
		if(isset($setting["js_obfuscate"])){
			$this->js_obfuscate = $setting["js_obfuscate"];
		}
		
		if(isset($setting["htmlhex"])){
			$this->htmlhex = $setting["htmlhex"];
		}
	}
	
	public function addMetaTop($string = ""){
		array_push($this->meta_top, $string);
	}
	
	public function addCssLibrary($string){
		if(!is_array($string)){
			array_push($this->css_library, $string);
		}else{
			foreach($string as $s){
				array_push($this->css_library, $s);
			}
		}
	}
	
	public function addCustomCss($string = ""){
		array_push($this->custom_css, $string);
	}
	
	public function addTopScriptLibrary($string = ""){
		array_push($this->top_script_library, $string);
	}
	
	public function addTopCustomScript($string = ""){
		array_push($this->top_custom_script, $string);
	}
	
	public function addBottomScriptLibrary($string = ""){
		array_push($this->bottom_script_library, $string);
	}
	
	public function addCustomScript($string = ""){
		array_push($this->custom_script, $string);
	}
	
	public function loadPage($page = ""){
		if(empty($page)){
			die("Fail including page. ");
		}
		
		$path = dirname(__DIR__) . "/App/View/pages/" . $page . ".php";
		
		if(!is_file($path)){
			$o = fopen($path, "w");
			fclose($o);
		}
		
		$this->page = $path;
	}
	
	public function Render(){
		$header = $this->Read("header");
		$footer = $this->Read("footer");
		
		$header = str_replace("{PAGE_TITLE}", $this->title, $header);
		
		$meta = "";
		foreach($this->meta_top as $r){
			$meta .= $r;
		}
		$header = str_replace("{META_TOP}", $meta, $header);
		
		$css = "<style>";
		foreach($this->css_library as $r){
			//$css .= $r;
			
			$filename = Router::get("path", $r);
			$path = dirname(__DIR__) . "/Assets/" . $filename;
			if(file_exists($path)){
				$css .= file_get_contents($path);
			}
		}
		$css .= "</style>";
		$header = str_replace("{CSS_LIBRARY}", $css, $header);
		
		$css = "";
		foreach($this->custom_css as $r){
			$css .= $r;
		}
		$header = str_replace("{CUSTOM_CSS}", $css, $header);
		
		
		$js = "";
		foreach($this->top_script_library as $r){
			$js .= $r;
		}
		$header = str_replace("{TOP_SCRIPT_LIBRARY}", $js, $header);
		
		$js = "";
		foreach($this->top_custom_script as $r){
			$js .= $r;
		}
		
		if($this->js_obfuscate){
			$pack = new Packer($js, 'Normal', true, false, true);
			$js = $pack->pack();
		}
		
		$header = str_replace("{TOP_CUSTOM_SCRIPT}", $js, $header);
		
		$js = "";
		foreach($this->bottom_script_library as $r){
			$js .= $r;
		}
		$footer = str_replace("{BOTTOM_SCRIPT_LIBRARY}", $js, $footer);
		
		$js = "";
		foreach($this->bottom_script_library as $r){
			$js .= $r;
		}
		$footer = str_replace("{BOTTOM_CUSTOM_SCRIPT}", $js, $footer);
		
		header("Content-Type: text/html");
		
		if($this->htmlhex){
			$hex = '
				function hex(hexx) {
				    var hex = hexx.toString();//force conversion
				    var str = "";
				    for (var i = 0; (i < hex.length && hex.substr(i, 2) !== "00"); i += 2)
				        str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
				    return str;
				}
			';
			$pack = new Packer($hex, 'Normal', true, false, true);
			$js = $pack->pack();
			echo "<script>" . $js . "hex('" . Encoder::stringToHex($header) . "');</script>";
		}else{
			echo $header;
		}
		
		if(!empty($this->page)){
			include_once($this->page);
		}
		
		if($this->htmlhex){
			echo "<script>hex('" . Encoder::stringToHex($footer) . "');</script>";
		}else{
			echo $footer;
		}
	}
	
	public function Read($type = "header"){
		$path = dirname(__DIR__) . "/App/View/theme/" . $type . ".php";
		$x = fopen($path, "r+");
		$string = stream_get_contents($x);
		
		return $string;
	}
}




































?>