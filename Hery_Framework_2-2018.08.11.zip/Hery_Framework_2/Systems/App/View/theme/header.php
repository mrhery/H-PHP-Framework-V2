<!DOCTYPE html>
<html>
<head>
	<title>{PAGE_TITLE}</title>
	{META_TOP}
	
	{CSS_LIBRARY}
	<style>
		{CUSTOM_CSS}
	</style>
	
	{TOP_SCRIPT_LIBRARY}
	<script>
		{TOP_CUSTOM_SCRIPT}
	</script>
</head>

<body>
	

