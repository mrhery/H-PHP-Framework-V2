{BOTTOM_SCRIPT_LIBRARY}
<script>
	{BOTTOM_CUSTOM_SCRIPT}
</script>
</body>
</html>