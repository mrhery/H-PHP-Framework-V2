<?php
require_once(dirname(dirname(dirname(__DIR__))) . "/Misc/document_access.php");


?>
<div class="container">
	<div class="row">
		<div class="col-md-12" style="margin-top: 20px;">
			<h1>
				Hello World
			</h1>
			<hr />
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					Form
				</div>
				
				<div class="card-body">
					<? new Controller(Input::get("submit")) ?>
					<form action="" method="POST">
						Name:
						<input type="text" class="form-control" placeholder="Name" name="name" /><br />
						
						Detail:
						<textarea class="form-control" placeholder="Details" name="detail"></textarea><br />
						
						<input type="hidden" name="route" value="item/add" />
						<button class="btn btn-success btn-block" name="submit" value="<?= $_SESSION["IR"] ?>">
							Send
						</button>
					</form>
					
					<form action="" method="POST">
						Name:
						<input type="text" class="form-control" placeholder="Namea" name="name" /><br />
						
						Detail:
						<textarea class="form-control" placeholder="Detailsa" name="detail"></textarea><br />
						
						<input type="hidden" name="route" value="item/test" />
						<button class="btn btn-success btn-block" name="submit" value="<?= $_SESSION["IR"] ?>">
							Send
						</button>
					</form>
				</div>
			</div>
		</div>
		
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					Fetch DB
				</div>
				
				<div class="card-body">
					<table class="table table-fluid table-hover">
						<thead>
							<tr>
								<th>Name</th>
								<th>Detail</th>
							</tr>
						</thead>
						
						<tbody>
						<?php
							$m = new Model("test");
							foreach($m->list() as $r){
						?>
							<tr>
								<td><?= $r->t_name ?></td>
								<td><?= $r->t_detail ?></td>
							</tr>
						<?php
							}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>






























