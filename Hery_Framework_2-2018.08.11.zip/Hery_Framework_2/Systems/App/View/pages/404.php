<?php
require_once(dirname(dirname(dirname(__DIR__))) . "/Misc/document_access.php");
?>

<div class="container">
	<br />
	<h1>
		404 Page Not Found
	</h1>
	<hr />
	
	<p>
		
	</p>
</div>