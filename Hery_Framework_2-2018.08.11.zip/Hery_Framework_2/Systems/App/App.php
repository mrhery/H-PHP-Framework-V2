<?php
require_once(dirname(__DIR__) . "/Misc/document_access.php");

class App{
	public function __construct($route = "", $autoload = false){
		$main = Router::get("main", $route);
		$path = __DIR__ . "/View/pages/" . $main . ".php";
		
		/*
			If you are creating page directly and not using Page Class, you may enable $autoload = true in new App() at index.php
		*/
		if($autoload){
			if(is_file(__DIR__ . "/View/pages/" . $main . ".php")){
				Loader::Include("header");
				include_once($path);
				Loader::Include("footer");
			}else{
				die("Requested file " . $main . ".php not found in current application directory.");
			}
		}else{
			$page = new Page();
			$page->addMetaTop();
			$page->addCssLibrary(array('assets/css/custom.css'));
			//$page->addCustomCss('body{background-color: black;}');
			$page->addTopScriptLibrary('<script src="assets/js/custom.js"></script>');
			
			switch($main){
				case "index":
				case "Home":
					$page->title = "This is a website";
					$page->loadPage("test");
					$page->Render();
				break;
				
				
				
				/*
				* Please left below cases and do not remove these line
				*/
				case "assets":
					$filename = Router::get("path", $route);
					
					if(!empty($filename)){
						Loader::Asset($filename);
					}else{
						$page->title = "Page Not Found";
						$page->loadPage("404");
						$page->Render();
					}
				break;
				
				case "medias":
					Loader::Image($route);
				break;
				
				default:
					$page->title = "Page Not Found";
					$page->loadPage("404");
					$page->Render();
				break;
			}
		}
	}
}

?>