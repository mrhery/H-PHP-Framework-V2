<?php
require_once(__DIR__ . "/Misc/document_access.php");

class Config{
	public static $host 	= "127.0.0.1";
	public static $database	= "workspac_bizdir";
	public static $username	= "workspac_hery";
	public static $password	= "hery@1234567890";
}

?>