<?php
defined("HFA") or die("You re not allowed to access this page.");
?>